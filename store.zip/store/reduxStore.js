import { createSlice, configureStore } from "@reduxjs/toolkit";

const initialState = {
  showModal: false,
  userId: null
};

const showModalSlice = createSlice({
  name: "authShowSlice",
  initialState,
  reducers: {
    modalShow(state) {
      state.showModal = true;
    },
    modalHide(state) {
      state.showModal = false;
    },
    setUserId(state, action) {
      state.userId = action.payload;
    },
    clearUserId(state) {
      state.userId = null;
    }
  }
});

const store = configureStore({
  reducer: {
    showAuth: showModalSlice.reducer
  }
});

export const showAuthActions = showModalSlice.actions;
export default store;
