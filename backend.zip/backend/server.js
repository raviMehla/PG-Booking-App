import fs from 'node:fs/promises';
import bodyParser from 'body-parser';
import express from 'express';
import cors from "cors";

const app = express();
const PORT = 3000;

app.use(express.static('images'));
app.use(bodyParser.json());
app.use(cors());

app.get('/data', async (req, res) => {
  try {
    const fileContent = await fs.readFile('./PropertyData.json');
    const placesData = JSON.parse(fileContent);
    const page = parseInt(req.query.page) || 1;
    const itemsPerPage = parseInt(req.query.itemsPerPage) || 10;
    const startIndex = (page - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedData = placesData.slice(startIndex, endIndex);
    res.status(200).json({ places: paginatedData });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});


// app.get('/data', async (req, res) => {
//   try {
//     const fileContent = await fs.readFile('./PropertyData.json');
//     const placesData = JSON.parse(fileContent);
//     res.status(200).json({ places: placesData });
//   } catch (error) {
//     res.status(500).json({ error: 'Internal server error' });
//   }
// });

app.get('/data/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const fileContent = await fs.readFile('./PropertyData.json');
    const placesData = JSON.parse(fileContent);
    const item = placesData.find(item => item.id === id);
    if (!item) {
      res.status(404).json({ error: 'Item not found' });
    } else {
      res.status(200).json(item);
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

const getPropertyData = async () => {
  try {
    const fileContent = await fs.readFile('./PropertyData.json', 'utf-8');
    return fileContent ? JSON.parse(fileContent) : [];
  } catch (error) {
    console.log("Error reading Propertydata.json:", error);
    return [];
  }
};

const getCustomerData = async () => {
  try {
    const fileContent = await fs.readFile('./Booking.json', 'utf-8');
    return fileContent ? JSON.parse(fileContent) : [];
  } catch (error) {
    console.log("Error reading Booking.json:", error);
    return [];
  }
};

app.post("/addProperty", async (req, res) => {
  try {
    const data = req.body;
    const fileData = await getPropertyData();
    const titleExist = fileData.some(property => property.title === data.title);

    if (titleExist) {
      return res.status(409).json({ error: "Title Exist already." })
    }
    fileData.push(data);
    await saveData("./PropertyData.json", fileData);
    res.sendStatus(204);
    console.log("property added successfully");
  }
  catch (error) {
    console.log("There is error in posting property data", error);
    res.status(500).json({ error: "internal error in property data entry server" })
  }
})

const getData = async () => {
  try {
    const fileContent = await fs.readFile('./PropertyOwnerProfile.json', 'utf-8');
    return fileContent ? JSON.parse(fileContent) : [];
  } catch (error) {
    console.log("Error reading Property Owner Profile.json:", error);
    return [];
  }
};

const getRequestsData = async () => {
  try {
    const fileContent = await fs.readFile('./HelpRequests.json', 'utf-8');
    return fileContent ? JSON.parse(fileContent) : [];
  } catch (error) {
    console.log("Error reading HelpRequest.json:", error);
    return [];
  }
};

const getDataRD = async () => {
  try {
    const fileContent = await fs.readFile('./PropertyOwnerRegData.json', 'utf-8');
    return fileContent ? JSON.parse(fileContent) : [];
  } catch (error) {
    console.log("Error reading registerData.json:", error);
    return [];
  }
};

const saveData = async (filePath, data) => {
  try {
    await fs.writeFile(filePath, JSON.stringify(data, null, 2));
  } catch (error) {
    console.log("Error saving data to", filePath, error);
    throw new Error('Error saving data');
  }
};

app.post('/registerData', async (req, res) => {
  try {
    const data = req.body;
    const fileData = await getDataRD();

    console.log("Checking if email exists:", data.email);
    const emailExists = fileData.some(user => user.email === data.email);

    if (emailExists) {
      console.log("Email already registered:", data.email);
      return res.status(409).json({ error: 'Email is already registered' });
    }

    console.log("Registering new user:", data.email);
    fileData.push(data);
    await saveData('./PropertyOwnerRegData.json', fileData);
    res.sendStatus(204);
    console.log("Data successfully saved to registerData.json");
  } catch (error) {
    console.log("Error saving data to registerData.json", error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/newAdded', async (req, res) => {
  try {
    res.status(200).json(await getData());
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/newAdded', async (req, res) => {
  try {
    const data = req.body;
    const fileData = await getData();
    fileData.push(data);
    await saveData('./PropertyOwnerProfile.json', fileData);
    res.sendStatus(204);
    console.log("Data successfully saved to newAdded.json");
  } catch (error) {
    console.log("Error saving data to newAdded.json", error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/bookingRequest', async (req, res) => {
  try {
    const data = req.body;
    const fileData = await getCustomerData();
    fileData.push(data);
    await saveData('./Booking.json', fileData);
    res.sendStatus(204);
    console.log("Data successfully saved to Booking.json");
  } catch (error) {
    console.log("Error saving data to newAdded.json", error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/contactrequest', async (req, res) => {
  try {
    const data = req.body;
    const fileData = await getRequestsData();
    fileData.push(data);
    await saveData('./HelpRequests.json', fileData);
    res.sendStatus(204);
    console.log("Data successfully saved to HelpRequest.json");
  } catch (error) {
    console.log("Error saving data to HelpRequest.json", error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/userDetail', async (req, res) => {
  try {
    const { userId } = req.body;
    const fileData = await getData();
    const userDetails = fileData.find(user => user.id === userId.userId);
    if (userDetails) {
      res.status(200).json(userDetails);
    } else {
      res.status(404).json({ error: 'User details not found' });
    }
  } catch (error) {
    console.log("Error occurred while fetching user details:", error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const fileData = await getDataRD();

    const user = fileData.find(user => user.email === email && user.password === password);

    if (user) {
      console.log("Login successful:", email);
      res.status(200).json({ userId: user.id });
    } else {
      console.log("Invalid credentials for:", email);
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch (error) {
    console.log("Error occurred while logging in:", error);
    res.status(500).json({ error: 'Internal server error' });
  }
});


app.use((req, res) => {
  res.status(404).json({ message: '404 - Not Found' });
});

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
