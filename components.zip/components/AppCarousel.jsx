import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";

const CarouselSection = function () {
  return (
    <div className="app-intro">
      <Carousel
        showThumbs={false}
        showIndicators={false}
        infiniteLoop={true}
        autoPlay={true}
        interval={5000}
      >
        <div>
          <h2>Welcome to Atithi.com!</h2>
          <p>
            Atithi.com is your go-to platform for finding and booking
            accommodations for your travels. Whether you're looking for a cozy
            homestay, a luxurious hotel, or a budget-friendly hostel, we've got
            you covered.
          </p>
        </div>
        <div>
          <h2>Discover Your Perfect Stay</h2>
          <p>
            Explore thousands of listings, read reviews from fellow travelers,
            and book with confidence. Your next adventure starts here!
          </p>
        </div>
      </Carousel>
    </div>
  );
};
export default CarouselSection;
