import { Outlet } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import CarouselSection from "./AppCarousel";
import AllItem from "./AllItem";
const Homepage = function () {
  return (
    <>
      <Outlet />
      <Header />
      <CarouselSection />
      <AllItem />
      <Footer />
    </>
  );
};
export default Homepage;
