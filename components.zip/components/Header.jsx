import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const Header = function () {
  const navigate = useNavigate();
  const isLoggedIn = useSelector((state) => state.showAuth.userId);

  function HandleRenderModal() {
    if (isLoggedIn) {
      navigate("/Homepage/authentication/login/userprofile");
    } else {
      navigate("/Homepage/authentication");
    }
  }
  function handleTitleClick() {
    navigate("/");
  }

  return (
    <div className="app-header">
      <h1 onClick={handleTitleClick} className="app-title">
        atithi.com
      </h1>
      <nav>
        <p onClick={HandleRenderModal}>List Property</p>
      </nav>
    </div>
  );
};
export default Header;
