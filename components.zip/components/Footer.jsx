import { useNavigate } from "react-router-dom";

const Footer = function () {
  const navigate = useNavigate();

  function HandleTermsClick() {
    navigate("/Homepage/terms&conditions");
  }

  function HandleContactClick() {
    navigate("/Homepage/contactUs");
  }

  return (
    <>
      <footer className="app-footer">
        <div className="footer-content">
          <p>
            &copy; {new Date().getFullYear()} atithi.com. All rights reserved.
          </p>
          <nav>
            <a className="footerLinks" onClick={HandleTermsClick}>
              Terms of Service
            </a>
            <a
              className="footerLinks"
              href="https://www.termsfeed.com/live/393260c6-b016-4352-94f4-399dc98b6010"
            >
              Privacy Policy
            </a>
            <a className="footerLinks" onClick={HandleContactClick}>
              Contact Us
            </a>
          </nav>
        </div>
      </footer>
    </>
  );
};
export default Footer;
