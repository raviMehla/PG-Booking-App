import { useState, useEffect } from "react";
import { sortPlacesByDistance } from "../util/loc";
import { Link } from "react-router-dom";

const AllItem = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [cityFilter, setCityFilter] = useState("");
  const [sortBy, setSortBy] = useState("");
  const [sortByDistance, setSortByDistance] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const itemsPerPage = 10;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          "http://localhost:3000/data?page=" + currentPage
        );

        if (!response.ok) {
          throw new Error("Failed to fetch data");
        }
        const responseData = await response.json();
        console.log("The data is in form of:", responseData.places);

        if (sortByDistance) {
          navigator.geolocation.getCurrentPosition((position) => {
            var sortedData = sortPlacesByDistance(
              responseData.places,
              position.coords.latitude,
              position.coords.longitude
            );
            console.log(
              "My coordinates are :",
              position.coords.latitude,
              position.coords.longitude
            );
            setData(sortedData);
            console.log("Sorted by Distance: ", sortedData);
            setLoading(false);
          });
        } else {
          setData(responseData.places);
          setLoading(false);
        }
      } catch (error) {
        setError(error);
        setLoading(false);
      }
    };

    fetchData();
  }, [currentPage, sortByDistance]);

  const handleCityFilterChange = (e) => {
    setCityFilter(e.target.value);
  };

  const handleSortByChange = (e) => {
    setSortBy(e.target.value);
  };

  function handleNearby() {
    setSortByDistance(!sortByDistance);
  }

  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
  };

  const filteredData = data
    ? data.filter((item) => {
        return (
          !cityFilter ||
          item.city.toLowerCase().includes(cityFilter.toLowerCase()) ||
          item.title.toLowerCase().includes(cityFilter.toLowerCase()) ||
          item.amenities.some((amenity) =>
            amenity.toLowerCase().includes(cityFilter.toLowerCase())
          )
        );
      })
    : [];

  const sortedData = filteredData.slice().sort((a, b) => {
    if (sortBy === "priceLowToHigh") {
      return a.price_per_month - b.price_per_month;
    } else if (sortBy === "priceHighToLow") {
      return b.price_per_month - a.price_per_month;
    } else {
      return 0;
    }
  });

  if (loading)
    return (
      <center>
        <div className="loading">Loading...</div>
      </center>
    );
  if (error)
    return (
      <center>
        <div className="error">Error: {error.message}</div>
      </center>
    );
  if (!data)
    return (
      <center>
        <div className="no-data">No data available</div>
      </center>
    );

  return (
    <div className="container">
      <div className="filter-sort-container">
        <div className="filter">
          <label htmlFor="cityFilter">Filter by City:</label>
          <input
            type="text"
            id="cityFilter"
            value={cityFilter}
            onChange={handleCityFilterChange}
          />
        </div>

        <div className="sort">
          <label className="price_sort" htmlFor="sortBy">
            Sort by Price:
          </label>
          <select
            className="sortbyprice"
            id="sortBy"
            value={sortBy}
            onChange={handleSortByChange}
          >
            <option value="">-- Select --</option>
            <option value="priceLowToHigh">Low to High</option>
            <option value="priceHighToLow">High to Low</option>
          </select>
          <button className="nearby_btn" onClick={handleNearby}>
            Nearby me
          </button>
        </div>
      </div>

      <div className="items-container">
        {sortedData.length === 0 ? (
          <div className="no-data">No matching data found</div>
        ) : (
          sortedData.map((item) => (
            <div key={item.id} className="item">
              <img src="./4th.jpeg" alt={item.image.alt} />
              <div className="item-details">
                <h2>{item.title}</h2>
                <p>City: {item.city}</p>
                <p>Price per month: ${item.price_per_month}</p>
                <p>Rooms available: {item.rooms_available}</p>
                <p>Amenities: {item.amenities.join(", ")}</p>

                <Link to={`/Homepage/item/${item.id}`}>
                  <button className="view-detail-btn">View Detail</button>
                </Link>
              </div>
            </div>
          ))
        )}
      </div>
      <center>
        <div className="pagination">
          <button
            className="pagiBtn"
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          >
            Prev
          </button>
          <span className="pagiSpan">Page {currentPage}</span>
          <button
            className="pagiBtn"
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={data.length < itemsPerPage}
          >
            Next
          </button>
        </div>
      </center>
    </div>
  );
};

export default AllItem;
