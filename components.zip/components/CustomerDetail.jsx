import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Modal from "../UI/Modal";

const CustomerDetail = function () {
  const navigate = useNavigate();
  const params = useParams();

  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [bookingID, setBookingID] = useState(null);

  const [formData, setFormData] = useState({
    customerName: "",
    email: "",
    phone: "",
    profession: "",
    memberCount: "",
  });

  function handleCloseModal() {
    navigate("/");
  }

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const generatedId = generateOrderId();

    const formDataWithId = {
      ...formData,
      BookingId: generatedId,
      PropertyId: params.id,
    };

    if (
      formDataWithId.customerName.trim() === "" ||
      formDataWithId.email.trim() === "" ||
      formDataWithId.phone.trim() === "" ||
      formDataWithId.profession.trim() === "" ||
      formDataWithId.memberCount.trim() === ""
    ) {
      alert("Every field should be filled");
      return;
    }

    setIsLoading(true);
    setError(null);
    setSubmitSuccess(false);

    try {
      setBookingID(formDataWithId.BookingId);
      const response = await fetch("http://localhost:3000/bookingRequest", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formDataWithId),
      });

      if (response.ok) {
        const responseData = response.status;
        console.log("Booking request sent successfully");
        console.log("Response data from Booking:", responseData);

        setSubmitSuccess(true);
        setTimeout(() => {
          setFormData({
            customerName: "",
            email: "",
            phone: "",
            profession: "",
            memberCount: "",
          });
        }, 2000);
      } else if (response.status === 401) {
        setError("Invalid Credential");
      } else {
        setError("Failed to submit the booking request");
      }
    } catch (error) {
      console.error("Error occurred during Booking request", error);
      setError("An unexpected error occurred during Booking Request");
    } finally {
      setIsLoading(false);
    }

    console.log("Form submitted:", formDataWithId);
  };

  const generateOrderId = () => {
    return Math.random().toString(36).substr(2, 10);
  };

  return (
    <>
      <Modal>
        <div className="contact-us">
          <button className="close-button" onClick={handleCloseModal}>
            X
          </button>
          <h2>Booking Form</h2>
          {isLoading && <p>Loading...</p>}
          {error && <p className="error-message">{error}</p>}
          {submitSuccess && (
            <p className="success-message">
              Booking request sent successfully! Your Booking ID is{" "}
              <b>{bookingID}</b>. Our team will reach you soon.
            </p>
          )}
          {!submitSuccess && (
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="customerName">Your Name:</label>
                <input
                  type="text"
                  id="customerName"
                  name="customerName"
                  value={formData.customerName}
                  onChange={handleChange}
                  required
                  className="form-control"
                  disabled={isLoading}
                />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email:</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="form-control"
                  disabled={isLoading}
                />
              </div>
              <div className="form-group">
                <label htmlFor="phone">Phone:</label>
                <input
                  type="text"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="form-control"
                  disabled={isLoading}
                />
              </div>
              <div className="form-group">
                <label htmlFor="profession">Profession:</label>
                <input
                  id="profession"
                  name="profession"
                  value={formData.profession}
                  onChange={handleChange}
                  required
                  className="form-control"
                  disabled={isLoading}
                />
              </div>
              <div className="form-group">
                <label htmlFor="memberCount">No of Member:</label>
                <input
                  type="number"
                  id="memberCount"
                  name="memberCount"
                  value={formData.memberCount}
                  onChange={handleChange}
                  required
                  className="form-control"
                  disabled={isLoading}
                />
              </div>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={isLoading}
              >
                Submit
              </button>
            </form>
          )}
        </div>
      </Modal>
    </>
  );
};

export default CustomerDetail;
