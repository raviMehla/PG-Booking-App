import Modal from "../UI/Modal";
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

const ItemDetail = function () {
  const params = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  console.log("Params are :", params);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`http://localhost:3000/data/${params.id}`);

        if (!response.ok) {
          throw new Error("Failed to fetch Data");
        }
        const responseData = await response.json();
        console.log("Data specifi id :", responseData);
        setData(responseData);
        setLoading(false);
      } catch (error) {
        setError(error);
        setLoading(false);
      }
    };

    fetchData();
  }, [params.id]);

  function handleViewAll() {
    navigate("/");
  }

  function handleBooking() {
    navigate(`/Homepage/item/${params.id}/bookingRequest`);
  }

  if (loading) {
    return (
      <Modal>
        <div className="detailDiv">
          <div></div>
          <button className="item-detail-btn" onClick={handleViewAll}>
            View All
          </button>
          <div className="item-detail-loading">Loading...</div>
        </div>
      </Modal>
    );
  }

  if (error) {
    return (
      <Modal>
        <div className="detailDiv">
          <div></div>
          <button className="item-detail-btn" onClick={handleViewAll}>
            View All
          </button>
          <div className="item-detail-error">Error: {error.message}</div>
        </div>
      </Modal>
    );
  }

  return (
    <Modal>
      <div className="detailDiv">
        <button className="item-detail-btn" onClick={handleViewAll}>
          View All
        </button>
        <div className="item-detail-container">
          <h1>Detail</h1>
          <img src="./4th.jpeg" alt={"Hostel"} />
          <div className="item-details">
            <h2>{data.title}</h2>
            <p>City: {data.city}</p>
            <p>Price per month: ${data.price_per_month}</p>
            <p>Rooms available: {data.rooms_available}</p>
            <p>Amenities: {data.amenities.join(", ")}</p>
            <button onClick={handleBooking} className="booking-btn">
              Booking Request
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
export default ItemDetail;
