import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Modal from "../UI/Modal";

const ContactUs = () => {
  const navigate = useNavigate();

  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [requestID, setRequestID] = useState(null);

  const [formData, setFormData] = useState({
    customerName: "",
    email: "",
    phone: "",
    message: "",
  });

  function handleCloseModal() {
    navigate("/");
  }

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const generatedId = generateInquiryId();

    const formDataWithId = {
      ...formData,
      RequestID: generatedId,
    };

    if (
      formDataWithId.customerName.trim() === "" ||
      formDataWithId.email.trim() === "" ||
      formDataWithId.message.trim() === "" ||
      formDataWithId.message.trim() === ""
    ) {
      alert("Every Field should be filled");
      return;
    }

    setIsLoading(true);
    setError(null);
    setSubmitSuccess(false);

    try {
      setRequestID(formDataWithId.RequestID);
      const response = await fetch("http://localhost:3000/contactrequest", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formDataWithId),
      });

      if (response.ok) {
        const responseData = response.status;
        console.log("Help Request sent Successfully", responseData);
        setSubmitSuccess(true);
        setFormData({
          customerName: "",
          email: "",
          phone: "",
          message: "",
        });
        console.log("Form submitted:", formDataWithId);
      } else if (response.status === 401) {
        setError("Invalid Credential");
      } else {
        setError("Failed to submit request");
      }
    } catch (error) {
      console.error("Error occured during sending request.");
      setError("An unexpected error occurred during Sending Help Request");
    } finally {
      setIsLoading(false);
    }
  };

  const generateInquiryId = () => {
    return Math.random().toString(36).substr(2, 10);
  };

  return (
    <Modal>
      <div className="contact-us">
        <button className="close-button" onClick={handleCloseModal}>
          X
        </button>
        <h2>Booking Form</h2>
        {isLoading && <p>Loading...</p>}
        {error && <p className="error-message">{error}</p>}
        {submitSuccess && (
          <p className="success-message">
            Help request sent successfully! Your Request ID is{" "}
            <b>{requestID}</b>. Our team will reach you soon.
          </p>
        )}
        {!submitSuccess && (
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="customerName">Name:</label>
              <input
                type="text"
                id="customerName"
                name="customerName"
                value={formData.customerName}
                onChange={handleChange}
                required
                className="form-control"
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="form-control"
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Phone:</label>
              <input
                type="phone"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
                className="form-control"
              />
            </div>
            <div className="form-group">
              <label htmlFor="message">Message:</label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                className="form-control"
              />
            </div>
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </form>
        )}
      </div>
    </Modal>
  );
};

export default ContactUs;
