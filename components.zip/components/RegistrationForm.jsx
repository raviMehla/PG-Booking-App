import { useState } from "react";
import Modal from "../UI/Modal";
import { useNavigate } from "react-router-dom";

const PropertyForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    id: "",
    title: "",
    city: "",
    lat: 0,
    lon: 0,
    rooms_available: 0,
    amenities: [],
    price_per_month: 0,
  });

  function handleCloseModal() {
    navigate("/");
  }

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    const parsedValue = type === "number" ? parseFloat(value) : value;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: parsedValue,
    }));
  };

  const handleAmenitiesChange = (e) => {
    const amenitiesArray = e.target.value
      .split(",")
      .map((amenity) => amenity.trim());
    setFormData({ ...formData, amenities: amenitiesArray });
  };

  const generateUniqueId = () => {
    return "_" + Math.random().toString(36).substr(2, 9);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const id = generateUniqueId();
    const dataToSend = { ...formData, id };

    dataToSend.lat = parseFloat(dataToSend.lat);
    dataToSend.lon = parseFloat(dataToSend.lon);
    dataToSend.rooms_available = parseInt(dataToSend.rooms_available, 10);
    dataToSend.price_per_month = parseFloat(dataToSend.price_per_month);

    if (validateForm()) {
      try {
        const response = await fetch("http://localhost:3000/newAdded", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(dataToSend),
        });

        const data = await response.json();
        console.log(data);
      } catch (error) {
        console.error(error);
      }
    } else {
      alert("Please fill all required fields");
    }
  };

  const validateForm = () => {
    return (
      formData.title.trim() !== "" &&
      formData.city.trim() !== "" &&
      formData.lat !== 0 &&
      formData.lon !== 0 &&
      formData.rooms_available !== 0 &&
      formData.amenities.length !== 0 &&
      formData.price_per_month !== 0
    );
  };

  return (
    <Modal className="property-form-modal">
      <button className="close-button" onClick={handleCloseModal}>
        X
      </button>
      <form onSubmit={handleSubmit} className="property-form">
        <div className="form-group">
          <label htmlFor="title">Title:</label>
          <input
            type="text"
            id="title"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="city">City :</label>
          <input
            type="address"
            name="city"
            value={formData.city}
            onChange={handleChange}
            placeholder="Property Address"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="lat">Latitude :</label>
          <input
            type="number"
            name="lat"
            value={formData.lat}
            onChange={handleChange}
            placeholder="Latitude"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="lon">Longitude :</label>
          <input
            type="number"
            name="lon"
            value={formData.lon}
            onChange={handleChange}
            placeholder="Longitude"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="rooms_available">rooms_available :</label>
          <input
            type="number"
            name="rooms_available"
            value={formData.rooms_available}
            onChange={handleChange}
            placeholder="rooms_available"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="price_per_month">Price Per Head :</label>
          <input
            type="number"
            name="price_per_month"
            value={formData.price_per_month}
            onChange={handleChange}
            placeholder="Price Per Head"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="amenities">Amenities (comma-separated):</label>
          <input
            type="text"
            name="amenities"
            value={formData.amenities.join(",")}
            onChange={handleAmenitiesChange}
            placeholder="Amenities"
            required
          />
        </div>
        <button type="submit">Submit</button>
      </form>
    </Modal>
  );
};

export default PropertyForm;
