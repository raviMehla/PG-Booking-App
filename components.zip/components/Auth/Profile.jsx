import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Modal from "../../UI/Modal";

const CreateProfile = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [formData, setFormData] = useState({
    fullName: "",
    fatherName: "",
    motherName: "",
    mobileNum: "",
    idType: "",
    idNumber: "",
  });

  function handleCloseModal() {
    navigate("/");
  }

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    const parsedValue = type === "number" ? parseFloat(value) : value;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: parsedValue,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (validateForm()) {
      try {
        const response = await fetch("http://localhost:3000/newAdded", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ ...formData, id }),
        });

        if (response.ok) {
          try {
            const data = await response.json();
            console.log(data);
            navigate("/Homepage/authentication/login");
          } catch (jsonError) {
            console.error("Error parsing JSON:", jsonError);
            navigate("/Homepage/authentication/login");
          }
        } else {
          alert("Failed to submit the form");
        }
      } catch (error) {
        console.error("Error submitting form:", error);
      }
    } else {
      alert("Please fill all required fields");
    }
  };

  const validateForm = () => {
    return (
      formData.fullName.trim() !== "" &&
      formData.fatherName.trim() !== "" &&
      formData.motherName.trim() !== "" &&
      formData.mobileNum.trim() !== "" &&
      formData.idType.trim() !== "" &&
      formData.idNumber.trim() !== ""
    );
  };

  return (
    <Modal className="property-form-modal">
      <button className="close-button" onClick={handleCloseModal}>
        X
      </button>
      <form onSubmit={handleSubmit} className="property-form">
        <div className="form-group">
          <label htmlFor="fullName">Full Name:</label>
          <input
            type="text"
            id="fullName"
            name="fullName"
            value={formData.fullName}
            onChange={handleChange}
            placeholder="Full Name"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="fatherName">Father Name :</label>
          <input
            type="text"
            name="fatherName"
            value={formData.fatherName}
            onChange={handleChange}
            placeholder="Father Name"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="motherName">Mother Name :</label>
          <input
            type="text"
            name="motherName"
            value={formData.motherName}
            onChange={handleChange}
            placeholder="Mother Name"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="mobileNum">Mobile Num:</label>
          <input
            type="tel"
            name="mobileNum"
            value={formData.mobileNum}
            onChange={handleChange}
            placeholder="Contact Number"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="idType">Select ID Type:</label>
          <select
            id="idType"
            name="idType"
            value={formData.idType}
            onChange={handleChange}
            required
          >
            <option value="">--Select an ID--</option>
            <option value="aadhar">Aadhar Card</option>
            <option value="driving_license">Driving License</option>
            <option value="passport">Passport</option>
          </select>

          <label htmlFor="idNumber">Enter ID Number:</label>
          <input
            type="text"
            id="idNumber"
            name="idNumber"
            value={formData.idNumber}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">Submit</button>
      </form>
    </Modal>
  );
};

export default CreateProfile;
