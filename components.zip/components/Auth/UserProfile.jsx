import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import store, { showAuthActions } from "../../store/reduxStore";
import Modal from "../../UI/Modal";

const UserProfile = function () {
  const navigate = useNavigate();
  const [error, setError] = useState(null);
  const [data, setData] = useState();
  const [isLoading, setIsLoading] = useState(true);

  const UserId = useSelector((state) => state.showAuth.userId);

  useEffect(() => {
    const fetchData = async () => {
      try {
        if (!UserId) {
          setError(new Error("User ID not found. Please log in."));
          setIsLoading(false);
          return;
        }

        const response = await fetch("http://localhost:3000/userDetail", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ userId: UserId }),
        });
        if (!response.ok) {
          throw new Error("Failed to fetch data");
        }
        const responseData = await response.json();
        setData(responseData);
        setIsLoading(false);
        console.log("This data is from userdetail", responseData);
      } catch (error) {
        setError(error);
        setIsLoading(false);
      }
    };
    fetchData();
  }, [UserId]);

  function logout() {
    store.dispatch(showAuthActions.clearUserId());
    navigate("/");
  }

  function handleCloseModal() {
    navigate("/");
  }

  function handleErrorLogin() {
    navigate("/Homepage/authentication/login");
  }

  function handleAddproperty() {
    navigate("/Homepage/authentication/login/userprofile/addproperty");
  }

  return (
    <Modal>
      {error ? (
        <div>
          Error: {error.message}
          <a className="footerLinks" onClick={handleErrorLogin}>
            Click Here
          </a>
        </div>
      ) : isLoading ? (
        <div>Loading...</div>
      ) : (
        <div className="user-profile">
          <button className="close-button" onClick={handleCloseModal}>
            Home
          </button>
          <h2>UserId: {UserId?.userId}</h2>
          <h2>User Name: {data?.fullName}</h2>
          <h2>Mobile: {data?.mobileNum}</h2>
          <div className="user-profile">
            <button onClick={handleAddproperty} className="add-property-button">
              Add Property
            </button>
            <button onClick={logout} className="add-property-button">
              Logout
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
};

export default UserProfile;
