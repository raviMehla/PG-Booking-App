import { useState } from "react";
import Modal from "../../UI/Modal";
import store, { showAuthActions } from "../../store/reduxStore";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  const navigate = useNavigate();
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    setError("");
  };

  function handleCloseModal() {
    navigate("/");
  }

  const handleLogin = async () => {
    const { username, password } = formData;

    if (username.trim() === "" || password.trim() === "") {
      setError("Username and password are required");
    } else {
      try {
        const response = await fetch("http://localhost:3000/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email: username, password: password }),
        });

        if (response.ok) {
          const userId = await response.json();
          console.log(userId);
          store.dispatch(showAuthActions.setUserId(userId));
          console.log("Login successful!");
          navigate("/Homepage/authentication/login/userprofile");
          console.log("after navigation");
        } else if (response.status === 401) {
          setError("Invalid credentials");
        } else {
          setError("An unexpected error occurred");
        }
      } catch (error) {
        console.error("Error occurred while logging in:", error);
        setError("An unexpected error occurred");
      }
    }
  };

  return (
    <Modal>
      <div className="login-container">
        <button className="close-button" onClick={handleCloseModal}>
          X
        </button>
        <h2>Login</h2>
        {error && <p className="error-message">{error}</p>}
        <div className="input-container">
          <label>Username:</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
          />
        </div>
        <div className="input-container">
          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
          />
        </div>
        <button className="login-btn" onClick={handleLogin}>
          Login
        </button>
      </div>
    </Modal>
  );
};

export default Login;
