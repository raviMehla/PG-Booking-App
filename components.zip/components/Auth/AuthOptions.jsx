import { useNavigate } from "react-router-dom";
import Modal from "../../UI/Modal";

const AuthOptions = function () {
  const navigate = useNavigate();

  function hideModal() {
    navigate("/Homepage");
  }

  function handleLoginModal() {
    navigate("/Homepage/authentication/login");
  }

  function handleRegisterClick() {
    navigate("/Homepage/authentication/registration");
  }

  return (
    <>
      <Modal>
        <center>
          <h2>Login Or Register</h2>
          <button onClick={handleLoginModal} className="modal-btn">
            Login
          </button>
          <button onClick={handleRegisterClick} className="modal-btn">
            Register
          </button>
          <br />
          <button className="modal-cancel-btn" onClick={hideModal}>
            Back Home
          </button>
        </center>
      </Modal>
    </>
  );
};
export default AuthOptions;
