import { useState } from "react";
import Modal from "../../UI/Modal";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

const PropertyForm = () => {
  const [title, setTitle] = useState("");
  const [imageSrc, setImageSrc] = useState("");
  const [imageAlt, setImageAlt] = useState("");
  const [city, setCity] = useState("");
  const [lat, setLat] = useState("");
  const [lon, setLon] = useState("");
  const [pricePerMonth, setPricePerMonth] = useState("");
  const [roomsAvailable, setRoomsAvailable] = useState("");
  const [amenities, setAmenities] = useState("");

  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const UserId = useSelector((state) => state.showAuth.userId);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    if (
      (title.trim() === "" ||
        imageSrc.trim() === "" ||
        imageAlt.trim() === "" ||
        city.trim() === "" ||
        lat.trim() === "" ||
        lon.trim() === "" ||
        pricePerMonth.trim() === "" ||
        roomsAvailable.trim() === "",
      amenities.trim() === "")
    ) {
      setIsLoading(false);
      setError("Every field should be filled");
    } else {
      const propertyData = {
        id: Math.random().toString(36).substr(2, 9),
        OwnerId: UserId.userId,
        title,
        image: {
          src: imageSrc,
          alt: imageAlt,
        },
        city,
        lat: parseFloat(lat),
        lon: parseFloat(lon),
        price_per_month: parseInt(pricePerMonth, 10),
        rooms_available: parseInt(roomsAvailable, 10),
        amenities: amenities.split(",").map((item) => item.trim()),
      };
      console.log(propertyData);

      try {
        const response = await fetch("http://localhost:3000/addProperty", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(propertyData),
        });

        if (response.ok) {
          setIsLoading(false);
          console.log("Property Added successfully");
          const responseData = response.status;
          console.log("Response data of Prop reg is :", responseData);
          navigate("/Homepage/authentication/login/userprofile");
        } else if (response.status === 401) {
          setIsLoading(false);
          setError("Invalid Credentials");
        }
      } catch (error) {
        setIsLoading(false);
        console.error("Error occured during property registration", error);
        setError("An unexpected error occured during property reg");
      }
    }
  };

  return (
    <Modal>
      <button
        className="close-button"
        onClick={() => {
          navigate("/Homepage/authentication/login/userprofile");
        }}
      >
        X
      </button>
      <center>
        <h1>Property Registration Form</h1>
      </center>
      {error && <p className="error-message">{error}</p>}
      <form
        id="property-form"
        className="property-form"
        onSubmit={handleSubmit}
      >
        <div className="form-group">
          <label htmlFor="title">Title:</label>
          <input
            type="text"
            id="title"
            className="form-input"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="imageSrc">Image URL:</label>
          <input
            type="text"
            id="imageSrc"
            className="form-input"
            value={imageSrc}
            onChange={(e) => setImageSrc(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="imageAlt">Image Alt Text:</label>
          <input
            type="text"
            id="imageAlt"
            className="form-input"
            value={imageAlt}
            onChange={(e) => setImageAlt(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="city">City:</label>
          <input
            type="text"
            id="city"
            className="form-input"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="lat">Latitude:</label>
          <input
            type="number"
            id="lat"
            className="form-input"
            value={lat}
            onChange={(e) => setLat(e.target.value)}
            required
            step="0.0001"
          />
        </div>
        <div className="form-group">
          <label htmlFor="lon">Longitude:</label>
          <input
            type="number"
            id="lon"
            className="form-input"
            value={lon}
            onChange={(e) => setLon(e.target.value)}
            required
            step="0.0001"
          />
        </div>
        <div className="form-group">
          <label htmlFor="pricePerMonth">Price per Month:</label>
          <input
            type="number"
            id="pricePerMonth"
            className="form-input"
            value={pricePerMonth}
            onChange={(e) => setPricePerMonth(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="roomsAvailable">Rooms Available:</label>
          <input
            type="number"
            id="roomsAvailable"
            className="form-input"
            value={roomsAvailable}
            onChange={(e) => setRoomsAvailable(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="amenities">Amenities (comma-separated):</label>
          <input
            type="text"
            id="amenities"
            className="form-input"
            value={amenities}
            onChange={(e) => setAmenities(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="submit-button" disabled={isLoading}>
          {isLoading ? "Submitting..." : "Submit"}
        </button>
      </form>
    </Modal>
  );
};

export default PropertyForm;
