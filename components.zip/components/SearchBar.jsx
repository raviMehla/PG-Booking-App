import { useState } from "react";

const SearchBar = function () {
  const [searchTerm, setSearchTerm] = useState("");

  function handleSearch(event) {
    event.preventDefault();
    const inputValue = event.target.elements.search.value;
    setSearchTerm(inputValue);
    console.log("The search term is :", inputValue);
  }

  return (
    <div className="search-container">
      <form className="search-form" onSubmit={handleSearch}>
        <input
          type="search"
          placeholder="Search Here"
          name="search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />
        <button type="submit" className="search-button">
          Search
        </button>
      </form>
    </div>
  );
};
export default SearchBar;
