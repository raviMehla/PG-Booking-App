import Modal from "../UI/Modal";
import { useNavigate } from "react-router-dom";
const TermsAndConditions = () => {
  const navigate = useNavigate();

  function handleAgreeBtn() {
    navigate("/");
  }

  return (
    <Modal>
      <div className="terms-container">
        <h2 className="terms-heading">Terms and Conditions</h2>
        <p className="terms-text">
          Welcome to our website. If you continue to browse and use this
          website, you are agreeing to comply with and be bound by the following
          terms and conditions of use, which together with our privacy policy
          govern our relationship with you in relation to this website. If you
          disagree with any part of these terms and conditions, please do not
          use our website.
        </p>
        <p className="terms-text">
          The use of this website is subject to the following terms of use:
        </p>
        <ul className="terms-list">
          <li className="terms-list-item">
            The content of the pages of this website is for your general
            information and use only. It is subject to change without notice.
          </li>
          <li className="terms-list-item">
            This website uses cookies to monitor browsing preferences. If you do
            allow cookies to be used, the following personal information may be
            stored by us for use by third parties: [insert list of information].
          </li>
          <li className="terms-list-item">
            Neither we nor any third parties provide any warranty or guarantee
            as to the accuracy, timeliness, performance, completeness, or
            suitability of the information and materials found or offered on
            this website for any particular purpose. You acknowledge that such
            information and materials may contain inaccuracies or errors and we
            expressly exclude liability for any such inaccuracies or errors to
            the fullest extent permitted by law.
          </li>
          <li className="terms-list-item">
            Your use of any information or materials on this website is entirely
            at your own risk, for which we shall not be liable. It shall be your
            own responsibility to ensure that any products, services, or
            information available through this website meet your specific
            requirements.
          </li>
          <li className="terms-list-item">
            This website contains material which is owned by or licensed to us.
            This material includes, but is not limited to, the design, layout,
            look, appearance, and graphics. Reproduction is prohibited other
            than in accordance with the copyright notice, which forms part of
            these terms and conditions.
          </li>
        </ul>
        <p className="terms-text">
          By using this site, you agree to our{" "}
          <a
            href="https://www.termsfeed.com/live/393260c6-b016-4352-94f4-399dc98b6010"
            className="terms-link"
          >
            Privacy Policy
          </a>
        </p>
        <button onClick={handleAgreeBtn} className="agreebtn">
          Agree
        </button>
      </div>
    </Modal>
  );
};

export default TermsAndConditions;
